// $Id: Response.cpp 91671 2010-09-08 18:39:23Z johnnyw $

#include "ace/INet/Response.h"



ACE_BEGIN_VERSIONED_NAMESPACE_DECL

namespace ACE
{
  namespace INet
  {

    Response::Response () {}

    Response::~Response () {}

  }
}

ACE_END_VERSIONED_NAMESPACE_DECL
