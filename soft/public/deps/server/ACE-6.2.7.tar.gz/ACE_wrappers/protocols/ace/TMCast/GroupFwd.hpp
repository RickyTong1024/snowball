// $Id: GroupFwd.hpp 91626 2010-09-07 10:59:20Z johnnyw $
// author    : Boris Kolpackov <boris@dre.vanderbilt.edu>

#ifndef TMCAST_GROUP_FWD_HPP
#define TMCAST_GROUP_FWD_HPP

#include "Export.hpp"

namespace ACE_TMCast
{
  class Group;
}

#endif // TMCAST_GROUP_FWD_HPP
